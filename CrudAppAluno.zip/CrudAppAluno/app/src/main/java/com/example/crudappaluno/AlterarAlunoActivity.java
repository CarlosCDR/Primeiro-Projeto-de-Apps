package com.example.crudappaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class AlterarAlunoActivity extends AppCompatActivity{

    private BDSQLiteHelper bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_alterar_aluno);

        Intent intent = getIntent();
        final int id = intent.getIntExtra("ID", 0);
        bd = new BDSQLiteHelper(this);
        final Aluno aluno = bd.getaAluno(id);

        final EditText matricula = (EditText) findViewById(R.id.altMatricula);
        final EditText nome = (EditText) findViewById(R.id.altNome);
        matricula.setText(String.valueOf(aluno.getMatricula()));
        nome.setText(aluno.getNome());

        Button alterar = (Button) findViewById(R.id.btnAlterar);
        alterar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                aluno.setMatricula(Integer.parseInt(matricula.getText().toString()));
                aluno.setNome(nome.getText().toString());
                bd.updateAluno(aluno);
                Toast.makeText(getBaseContext(), "Aluno Alterado Com Sucesso!!!.", Toast.LENGTH_SHORT).show();
            }
        });

        Button remover = (Button) findViewById(R.id.btnRemover);
        remover.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                bd.deleteAluno(aluno);
                Toast.makeText(getBaseContext(), "Aluno Excluído Com Sucesso!!!.", Toast.LENGTH_SHORT).show();
            }
        });
    }
}