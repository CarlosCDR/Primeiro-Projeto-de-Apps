package com.example.crudappaluno;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.lang.reflect.Array;
import java.util.ArrayList;

public class BDSQLiteHelper extends SQLiteOpenHelper {

    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "AlunosDB";
    private static final String TABELA_ALUNOS = "alunos";
    private static final String ID = "id";
    private static final String MATRICULA = "matricula";
    private static final String NOME = "nome";

    private static final String[] COLUNAS = {ID, MATRICULA, NOME};

    public BDSQLiteHelper(Context context){
        super(context, DATABASE_NAME, null, DATABASE_VERSION);

    }

    @Override
    public void onCreate(SQLiteDatabase db) {
         String CREATE_TABLE = "CREATE TABLE alunos("+
                 "id INTEGER PRIMARY KEY AUTOINCREMENT," +
                 "matricula INTEGER,"+
                 "nome TEXT)";
         db.execSQL(CREATE_TABLE);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
           db.execSQL("DROP TABLE IF EXISTS alunos");
           this.onCreate(db);
    }

    public void addaluno(Aluno aluno){
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put(MATRICULA, new Integer(aluno.getMatricula()));
        values.put(NOME, aluno.getNome());

        db.insert(TABELA_ALUNOS, null, values);
        db.close();
    }
    public Aluno getaAluno(int id) {
        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.query(TABELA_ALUNOS,
                COLUNAS,
                "id = ?",
                new String[]{String.valueOf(id)},
                null,
                null,
                null);
        if (cursor == null) {
            return null;
        } else {
            cursor.moveToFirst();
            Aluno aluno = cursorToAluno(cursor);
            return aluno;
        }
    }

    private Aluno cursorToAluno(Cursor cursor){
        Aluno aluno = new Aluno();
        aluno.setId(Integer.parseInt(cursor.getString(0)));
        aluno.setMatricula(Integer.parseInt(cursor.getString(1)));
        aluno.setNome(cursor.getString(2));
        return aluno;
    }

    public ArrayList<Aluno> getAllAlunos(){
        ArrayList<Aluno> listaAlunos = new ArrayList<Aluno>();

        String query = "SELECT * FROM " +  TABELA_ALUNOS;

        SQLiteDatabase db = this.getReadableDatabase();
        Cursor cursor = db.rawQuery(query, null);

        if(cursor. moveToFirst()){
            do{
                Aluno aluno = cursorToAluno(cursor);
                listaAlunos.add(aluno);
            }while(cursor.moveToNext());

        }
        return listaAlunos;

    }

    public int updateAluno(Aluno aluno){
        SQLiteDatabase bd = this.getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put(MATRICULA, new Integer(aluno.getMatricula()));
        values.put(NOME, aluno.getNome());

        int i = bd.update(TABELA_ALUNOS,
                values,
                ID+" = ?",
                new String[] { String.valueOf(aluno.getId()) });
        bd.close();
        return i;
    }
    public int deleteAluno(Aluno aluno){
        SQLiteDatabase db = this.getWritableDatabase();

        int i = db.delete(TABELA_ALUNOS,
                ID+" = ?",
                new String[]{String.valueOf(aluno.getId())});
        db.close();
        return i;
    }

}