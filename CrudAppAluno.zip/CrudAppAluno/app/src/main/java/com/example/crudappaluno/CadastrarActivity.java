package com.example.crudappaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class CadastrarActivity extends AppCompatActivity {

    private BDSQLiteHelper bd;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_cadastrar);
        bd = new BDSQLiteHelper(this);

        final EditText matricula = (EditText) findViewById(R.id.altMatricula);
        final EditText nome = (EditText) findViewById(R.id.altNome);
        Button adicionar = (Button) findViewById(R.id.btnAlterar);
        adicionar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Aluno aluno = new Aluno();
                aluno.setMatricula(Integer.parseInt(matricula.getText().toString()));
                aluno.setNome(nome.getText().toString());
                bd.addaluno(aluno);

                Toast.makeText(getBaseContext(), "Aluno Cadastrado Com Sucesso", Toast.LENGTH_SHORT).show();

            }
        });
    }
}