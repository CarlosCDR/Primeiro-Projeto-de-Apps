package com.example.crudappaluno;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;

import java.util.ArrayList;

public class ListarAlunosActivity2 extends AppCompatActivity {

    private BDSQLiteHelper bd;
    ArrayList<Aluno> listaAlunos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bd = new BDSQLiteHelper(this);
        setContentView(R.layout.activity_listar_alunos2);
    }
   @Override
   protected void onStart() {
        super.onStart();
        ListView lista = (ListView) findViewById(R.id.lvAlunos);
        listaAlunos = bd.getAllAlunos();
        AlunoAdapter adapter = new AlunoAdapter(this, listaAlunos);
        lista.setAdapter(adapter);

        lista.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int i, long l) {
                Intent intent =  new Intent(ListarAlunosActivity2.this, AlterarAlunoActivity.class);
                intent.putExtra("ID", listaAlunos.get(i).getId());
                startActivity(intent);
            }
        });
    }
}