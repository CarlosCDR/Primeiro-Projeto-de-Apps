package com.example.crudappaluno;

import androidx.activity.result.contract.ActivityResultContracts;
import androidx.appcompat.app.AppCompatActivity;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    Button botao;
    Button botao2;
    private BDSQLiteHelper bd;
    //ArrayList<Aluno>listaAlunos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        bd = new BDSQLiteHelper(this);
        setContentView(R.layout.activity_main);
        botao = findViewById(R.id.btnCad);
        botao2 = findViewById(R.id.btnListar);

        botao.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),CadastrarActivity.class);
                startActivity(intent);
            }
        });
        botao2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(getApplicationContext(),ListarAlunosActivity2.class);
                startActivity(intent);
            }
        });
    }
   // @Override
   // protected void onStart() {
       // super.onStart();
        //ListView lista = (ListView) findViewById(R.id.lvAlunos);
       // listaAlunos = bd.getAllAlunos();
       // AlunoAdapter adapter = new AlunoAdapter(this, listaAlunos);
       // lista.setAdapter(adapter);
   // }

}